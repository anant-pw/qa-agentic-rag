"""
DIAGNOSTIC ONLY -- not part of the production system, not wired into
/generate, not added to docker-compose.yml or requirements.txt as a new
runtime dependency (uses httpx, already required).


Purpose: isolate ONE variable -- is phi4-mini's repeated hedging on
resolution/fix questions (Phase 6's Rule 2/2b investigation) a genuine
model-capacity ceiling, or something about this project's prompt/context
construction that a larger model would also fail on? Three prompt
variants already failed to change phi4-mini's behavior on BUG-1017 --
before concluding "model capacity," this runs the SAME retrieval, the
SAME context blocks, the SAME system prompt through a much larger model
(Groq-hosted openai/gpt-oss-120b) and prints both answers side by side.


Deliberately does NOT touch retrieval or embeddings -- hybrid_search()
still calls native Ollama for the query embedding, exactly as production
does. Only the final generation call is swapped. If retrieval/context
construction were the actual problem, both models would fail identically;
if it's phi4-mini's capacity, only the small model should fail.


This is local-first in spirit even though Groq is cloud: it's a one-time
diagnostic run, not a standing dependency the system needs to function.
If Groq's answer is materially better, that's evidence for the Phase 6
handoff's "known limitation" writeup -- it does NOT mean swapping the
production LLM to Groq, which would break the project's actual
local-first requirement and its explicit non-negotiable stated in
production-agentic-rag-project-brief.md. Keep this script, delete the
temptation to wire it in permanently.


Requires GROQ_API_KEY in the environment (get one at console.groq.com --
Groq has a permanent free tier, no card required as of this writing).
Not added to .env.example -- this is a manual, occasional diagnostic, not
part of the stack's normal configuration surface.


Run from the project root (needs `app` on sys.path, same reason
scripts/build_index.py is invoked with -m, not by path):
    GROQ_API_KEY=... python -m diagnostics.groq_probe --question \
        "What was the resolution or fix for BUG-1017 (Admin bulk export - resolved, follow-up to BUG-1007)?"
"""


import argparse
import logging
import os
import time

import httpx
import psycopg2
from opensearchpy import OpenSearch

from app.search.service import get_client, hybrid_search
from app.generation.context import fetch_structured_fields, fetch_references
from app.generation.prompt import build_messages, format_doc_context, SYSTEM_PROMPT
from app.generation.llm import stream_chat
from app.config import settings


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


GROQ_URL = "https://api.groq.com/openai/v1/chat/completions"
GROQ_MODEL = "openai/gpt-oss-120b"  # current Groq general-purpose/reasoning
# recommendation as of this writing -- llama-3.3-70b-versatile is being
# deprecated on Groq, do not silently fall back to it if this breaks;
# check https://console.groq.com/docs/deprecations for the current list
# before assuming the model id below still exists.


def build_real_context(question: str, pg_host, pg_port, pg_db, pg_user, pg_password,
                       os_host, os_port, ollama_host, ollama_port, alias,
                       doc_type=None, module=None, status=None) -> tuple[list[dict], list[str]]:
    """Reuses the EXACT production functions (app.search.service,
    app.generation.context, app.generation.prompt) to reproduce what
    app/routers/generate.py would build for this question -- same
    retrieval, same doc_type-aware context blocks, same system prompt.
    Only the final model call is swapped by the caller.

    doc_type/module/status added after a real diagnostic mistake: the
    first version of this script never passed structured filters to
    hybrid_search() at all, so a structured_filter comparison run (e.g.
    "How many bugs are Open in Login") silently ran UNFILTERED retrieval
    -- both Ollama and Groq answered from whatever 5 documents matched
    the raw question text semantically, which for that query was mostly
    wrong (1 of 5 retrieved docs actually matched Login+Open). Both
    models agreeing on an answer is not evidence the answer is right if
    the input they were both given was already wrong -- confirmed by
    comparing against live Postgres ground truth (4 Login+Open bugs, not
    1). This is the same class of bug eval/run_eval_generation.py's
    original call_generate() had, fixed the same way: forward the actual
    filters through, don't rely on the raw question text alone."""
    os_client = get_client(os_host, os_port)
    hits = hybrid_search(
        os_client, alias=alias, q=question,
        ollama_host=ollama_host, ollama_port=ollama_port, size=10,
        doc_type=doc_type, module=module, status=status,
    )
    top_hits = hits[:5]  # matches generate.py's CONTEXT_TOP_N

    pg_conn = psycopg2.connect(host=pg_host, port=pg_port, dbname=pg_db, user=pg_user, password=pg_password)
    try:
        doc_ids = [h["parent_document_id"] for h in top_hits]
        structured_by_id = fetch_structured_fields(pg_conn, doc_ids)
        references_by_id = fetch_references(pg_conn, doc_ids)
    finally:
        pg_conn.close()

    context_blocks = [
        format_doc_context(
            h,
            structured_by_id.get(h["parent_document_id"], {}),
            references_by_id.get(h["parent_document_id"], []),
        )
        for h in top_hits
    ]
    return context_blocks, [h["external_id"] for h in top_hits]


def call_groq(messages: list[dict]) -> str:
    api_key = settings.groq_api_key
    if not api_key:
        raise RuntimeError("GROQ_API_KEY is missing from .env or the process environment")

    start_time = time.perf_counter()
    try:
        resp = httpx.post(
            GROQ_URL,
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json={"model": GROQ_MODEL, "messages": messages, "temperature": 0.1},
            # temperature 0.1 to match this project's own Ollama pinning
            # convention (Phase 5 decision, see project memory) -- keeps the
            # comparison about model capacity, not about one side being more
            # random than the other.
            timeout=60,
        )
        resp.raise_for_status()
        return resp.json()["choices"][0]["message"]["content"]
    finally:
        end_time = time.perf_counter()
        total_time = end_time - start_time
        logger.info(
            "groq_chat_stats: model=%s total_time_sec=%.3f",
            GROQ_MODEL,
            total_time,
        )


def call_ollama(
    messages: list[dict],
    ollama_host: str,
    ollama_port: int,
    model: str = "phi4-mini:latest",
    think: bool | None = None,
) -> str:
    """Calls Ollama /api/chat via stream_chat and logs:
      - time_to_first_token_sec
      - total_generation_time_sec
      - total_tokens (eval_count from the final done chunk, if present)

    think: passed straight through to stream_chat's new "think" param --
    see app/generation/llm.py's docstring for why this exists (qwen3.5:9b's
    500-670s runs turned out to be dominated by an unrequested reasoning
    trace, not attention cost, once total_tokens was compared against the
    visible answer length).
    """
    start_time = time.perf_counter()
    first_token_time = None
    total_tokens = None

    fragments = []
    try:
        for content, maybe_done_chunk in stream_chat(
            messages,
            ollama_host,
            ollama_port,
            model=model,
            think=think,
            log_stats=False,  # we log here instead
        ):
            if first_token_time is None:
                first_token_time = time.perf_counter()
            fragments.append(content)

            if maybe_done_chunk and maybe_done_chunk.get("done"):
                total_tokens = maybe_done_chunk.get("eval_count")

    finally:
        end_time = time.perf_counter()
        total_generation_time = end_time - start_time
        time_to_first_token = (
            (first_token_time - start_time) if first_token_time is not None else None
        )

        logger.info(
            "ollama_chat_stats: model=%s time_to_first_token_sec=%.3f total_generation_time_sec=%.3f total_tokens=%s",
            model,
            time_to_first_token or 0.0,
            total_generation_time,
            total_tokens,
        )

    return "".join(fragments)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--question", required=True)
    parser.add_argument("--pg-host", default=os.environ.get("POSTGRES_HOST", "127.0.0.1"))
    parser.add_argument("--pg-port", default=os.environ.get("POSTGRES_PORT", "5433"))
    parser.add_argument("--pg-db", default=os.environ.get("POSTGRES_DB", "rag_db"))
    parser.add_argument("--pg-user", default=os.environ.get("POSTGRES_USER", "rag_user"))
    parser.add_argument("--pg-password", default=os.environ.get("POSTGRES_PASSWORD", "rag_password"))
    parser.add_argument("--os-host", default=os.environ.get("OPENSEARCH_HOST", "localhost"))
    parser.add_argument("--os-port", type=int, default=int(os.environ.get("OPENSEARCH_PORT", 9200)))
    parser.add_argument("--ollama-host", default=os.environ.get("OLLAMA_HOST", "localhost"))
    parser.add_argument("--ollama-port", type=int, default=int(os.environ.get("OLLAMA_PORT", 11434)))
    parser.add_argument("--ollama-model", default=os.environ.get("OLLAMA_CHAT_MODEL", "phi4-mini:latest"),
                        help="Try e.g. gpt-oss:20b, llama3.1:8b, or phi4:14b to compare against the "
                             "default -- see KNOWN_LIMITATIONS_generation.md for why this matters.")
    parser.add_argument("--alias", default=os.environ.get("OPENSEARCH_INDEX_ALIAS", "qa_documents"))
    parser.add_argument("--doc-type", default=None, help="Filter, e.g. bug_report")
    parser.add_argument("--module", default=None, help="Filter, e.g. Login")
    parser.add_argument("--status", default=None, help="Filter, e.g. Open")
    parser.add_argument("--think", default=None, choices=["true", "false"],
                         help="Pass Ollama's 'think' param for hybrid-reasoning models "
                              "(qwen3.5, deepseek-r1, etc.). Omit to use the model's default. "
                              "Try --think false on qwen3.5:9b if it's unexpectedly slow.")
    args = parser.parse_args()

    context_blocks, doc_ids = build_real_context(
        args.question, args.pg_host, args.pg_port, args.pg_db, args.pg_user, args.pg_password,
        args.os_host, args.os_port, args.ollama_host, args.ollama_port, args.alias,
        doc_type=args.doc_type, module=args.module, status=args.status,
    )
    messages = build_messages(args.question, context_blocks)

    print(f"Retrieved (top 5): {doc_ids}\n")
    print("=" * 60)
    print(f"OLLAMA ({args.ollama_model}) answer:")
    print("=" * 60)
    think_arg = None if args.think is None else (args.think == "true")
    print(call_ollama(messages, args.ollama_host, args.ollama_port, args.ollama_model, think=think_arg))

    print("\n" + "=" * 60)
    print(f"GROQ ({GROQ_MODEL}) answer, SAME messages/system prompt:")
    print("=" * 60)
    print(call_groq(messages))